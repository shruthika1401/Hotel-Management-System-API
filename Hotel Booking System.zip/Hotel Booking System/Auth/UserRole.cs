﻿namespace Hotel_Booking_System.Auth
{
    public class UserRoles
    {
        public const string Admin = "admin";
        public const string User = "admin";
    }

}
